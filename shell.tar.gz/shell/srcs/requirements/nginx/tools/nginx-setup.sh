#!/bin/sh
mkdir -p /var/www/wordpress

echo 'rc_provide="loopback net"' >> /etc/rc.conf

exec $@