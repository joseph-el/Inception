#!/bin/sh

/etc/init.d/mariadb setup
/etc/init.d/mariadb start

chown mysql: /var/run/mysqld

mariadb -u root -e "CREATE DATABASE ${DATABASE_NAME};"
mariadb -u root -e "CREATE USER '${DATABASE_USER}'@'%' IDENTIFIED BY '${DATABASE_PASSWORD}';"
mariadb -u root -e "GRANT ALL PRIVILEGES ON ${DATABASE_NAME}.* TO '${DATABASE_USER}'@'%';"
mariadb -u root -e "FLUSH PRIVILEGES;"
mariadb -u root -e "ALTER USER 'root'@'localhost' IDENTIFIED  BY '${ROOT_PASSWORD}';"

sleep 2

/etc/init.d/mariadb stop

exec $@